import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Login({ setIsAuthenticated }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:5000/DayBook/login', { username, password });
      localStorage.setItem('token', response.data.token);
      setIsAuthenticated(true);
      navigate('/Admin');
    } catch (err) {
      setError('שם משתמש או סיסמה שגויים');
    }
  };

  return (
    <div>
      <h1>התחברות</h1>
      {error && <p>{error}</p>}
      <form onSubmit={handleLogin}>
        <label>שם משתמש:</label>
        <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} required />
        <label>סיסמה:</label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        <button type="submit">התחבר</button>
      </form>
    </div>
  );
}
